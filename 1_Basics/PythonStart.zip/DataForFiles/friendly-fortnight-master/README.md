# K-Means Clustering using Python from Scratch

This repo is associated with [this](https://mubaris.com/2017-10-01/kmeans-clustering-in-python) blog post.
