And she started to create new worlds 
we are all one
wrwf
ewrw
e
wr
w
rw
rw
rw
pain has the ability to change a personhatredis too mucb to bear