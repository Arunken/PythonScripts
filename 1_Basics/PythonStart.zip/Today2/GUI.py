# -*- coding: utf-8 -*-
"""
Created on Sun Feb 25 14:33:59 2018

@author: Ourabora
"""

from tkinter import *
root = Tk()
root.mainloop()


l1 = Label(root,text='Pavan')
l2 = Label(root,text='is')
l2 = Label(root,text='teaching')
l2 = Label(root,text='python')
l2 = Label(root,text='online')

l1.grid(row = 100,column = 100)


import tkinter as tk

root = tk.Tk()

l1 = tk.Label(root,text='Hello Tkinter!')
l1.pack()

root.mainloop()

