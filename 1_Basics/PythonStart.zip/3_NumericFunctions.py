

# Return the character of the given ASCII value

a = chr(67)

# Returns the ASCII value of the character

b = ord('A')

# Returns the absolute value fo the number

c = abs(-64)

# Returns both the quotient and remainder 

q,r = divmod(16,5)

# returns the rounded number 

a = round(4.33444333,5) # max five digits after decimal point
print(a)


import math
x = math.ceil(5.33) # 6
y = math.floor(5.87) # 5
z = math.sqrt(4)


