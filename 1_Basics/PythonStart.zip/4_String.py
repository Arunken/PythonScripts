


a = 'Arun'
b = 'Kengayil'


# Concatenation

x = a+b
print(x)

# Repetition

print(a*3)

# Indexing

c = x[0] # A
d = x[3] # n

# Negative indexing :

e = x[-1]
f = x[-3]
g = x[-5]

# Slices :

h = x[2:4]
i = x[2:9:2] # take the character sequence from 2 to 9 and then return the characters with that are separated by 2 indexes

print(c)
print(d)
print(e)
print(f)
print(g)
print(h)
print(i)

