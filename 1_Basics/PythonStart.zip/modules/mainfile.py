# -*- coding: utf-8 -*-
"""
Created on Fri May 25 10:01:38 2018

@author: SilverDoe
"""


from nameduser import User

obj = User()
print(obj.convertToUpper('arunken'))
    
        