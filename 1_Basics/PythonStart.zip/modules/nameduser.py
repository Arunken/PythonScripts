# -*- coding: utf-8 -*-
"""
Created on Fri May 25 10:01:38 2018

@author: SilverDoe
"""

class User:
    
    def convertToUpper(self,name):
        return name.upper()
    
        