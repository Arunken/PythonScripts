# -*- coding: utf-8 -*-
"""
Created on Fri Jun 22 17:52:06 2018

@author: SilverDoe
"""


# A Python program to demonstrate working of key 
# value change in OrderedDict
from collections import OrderedDict
 
print("Before:\n")
od = OrderedDict()
od['a'] = 1
od['b'] = 2
od['c'] = 3
od['d'] = 4
for key, value in od.items():
    print(key, value)
 
print("\nAfter:\n")
od['c'] = 5
for key, value in od.items():
    print(key, value)



# A Python program to demonstrate working of deletion 
# re-inserion in OrderedDict
from collections import OrderedDict
 
print("Before deleting:\n")
od = OrderedDict()
od['a'] = 1
od['b'] = 2
od['c'] = 3
od['d'] = 4
 
for key, value in od.items():
    print(key, value)
 
print("\nAfter deleting:\n")
od.pop('c')
for key, value in od.items():
    print(key, value)
 
print("\nAfter re-inserting:\n")
od['c'] = 3
for key, value in od.items():
    print(key, value)