

# finding the quotient without fractional values
a = 9
b = 2
x = a/b # 4.5
c = a//b # 4
print(c)

# finding the quotient with fractional values

d = a/b
print(d)

# cube of a number

e = a**3
print(e)

# number assignment

a,b,c=10,20,30
print('a = ',a)
print('b = ',b)
print('c = ',c)

a = str(2878792234454)

print('occurence of 2 in the number : ',a.count('2'),' times')

