# -*- coding: utf-8 -*-
"""
Created on Sat Jul 28 23:04:58 2018

@author: SilverDoe
"""

for i in range(input('enter the limit')):
    k = [0, 1, 121, 12321]; print(k[i])
    
for i in range(1,int(input('enter the limit'))): #More than 2 lines will result in 0 score. Do not leave a blank 
    print((10**(i)//9)*i)
    
    
