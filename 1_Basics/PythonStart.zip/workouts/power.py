# -*- coding: utf-8 -*-
"""
Created on Sat Jul 28 23:16:40 2018

@author: SilverDoe
"""
a = int(input('enter the number'))
b = int(input('enter the degree'))
m = int(input('enter the mode'))
print(pow(a,b),pow(a,b,m),sep='\n')