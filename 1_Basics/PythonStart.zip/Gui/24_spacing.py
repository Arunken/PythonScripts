# -*- coding: utf-8 -*-
"""
Created on Fri Jun  1 00:00:14 2018

@author: SilverDoe
"""

lbl1 = Label(tab1, text= 'label1', padx=5, pady=5)